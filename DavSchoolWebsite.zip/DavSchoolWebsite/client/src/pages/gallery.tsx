import ImageGallery from "@/components/image-gallery";

export default function Gallery() {
  return (
    <div className="py-16">
      <ImageGallery />
    </div>
  );
}
